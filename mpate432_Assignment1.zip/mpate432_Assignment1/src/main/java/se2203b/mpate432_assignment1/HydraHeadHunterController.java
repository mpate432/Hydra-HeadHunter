package se2203b.mpate432_assignment1;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import java.util.ArrayList;
import java.util.Random;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.text.Font;

import java.util.*;

public class HydraHeadHunterController {

    @FXML
    private Button playButton;
    @FXML
    private Slider slider;
    @FXML
    private AnchorPane pane;
    private int counter;

    Image hydra1Img = new Image("file:src/main/resources/se2203b/mpate432_assignment1/HeadSize1.png");
    Image hydra2Img = new Image("file:src/main/resources/se2203b/mpate432_assignment1/HeadSize2.png");
    Image hydra3Img = new Image("file:src/main/resources/se2203b/mpate432_assignment1/HeadSize3.png");
    Image hydra4Img = new Image("file:src/main/resources/se2203b/mpate432_assignment1/HeadSize4.png");
    Image hydra5Img = new Image("file:src/main/resources/se2203b/mpate432_assignment1/HeadSize5.png");
    Image hydra6Img = new Image("file:src/main/resources/se2203b/mpate432_assignment1/HeadSize6.png");

    Image arrayHydraHeads[] = new Image[]{hydra1Img, hydra2Img, hydra3Img, hydra4Img, hydra5Img, hydra6Img};
    private ArrayList<ImageView> displayedHeads = new ArrayList<>();


    @FXML
    public void onPlayButtonClick() {
        int startingHead = (int) slider.getValue();
        playButton.setDisable(true);
        slider.setDisable(true);

        ImageView headDisplay = new ImageView();
        headDisplay.setImage(arrayHydraHeads[startingHead - 1]);
        headDisplay.setFitHeight(40);
        headDisplay.setFitWidth(40);

        Random randomLocation = new Random();
        headDisplay.setTranslateX(randomLocation.nextInt(680));
        headDisplay.setTranslateY(randomLocation.nextInt(680));

        pane.getChildren().add(headDisplay);
        displayedHeads.add(headDisplay);

        headDisplay.setOnMouseClicked(mouseEvent -> {
            pane.getChildren().remove(headDisplay);
            counter++;
            if(headDisplay.getImage().equals(arrayHydraHeads[1])){
                for(int i = 0; i < (int)(Math.random()*2)+2; i++) {
                    insertImage(0);
                }
            }
            else if(headDisplay.getImage().equals(arrayHydraHeads[2])){
                for(int i = 0; i < (int)(Math.random()*2)+2; i++) {
                    insertImage(1);
                }
            }
            else if(headDisplay.getImage().equals(arrayHydraHeads[3])){
                for(int i = 0; i < (int)(Math.random()*2)+2; i++) {
                    insertImage(2);
                }
            }
            else if(headDisplay.getImage().equals(arrayHydraHeads[4])){
                for(int i = 0; i < (int)(Math.random()*2)+2; i++) {
                    insertImage(3);
                }
            }
            else if(headDisplay.getImage().equals(arrayHydraHeads[5])){
                for(int i = 0; i < (int)(Math.random()*2)+2; i++) {
                    insertImage(4);
                }
            }
        });
    }
    @FXML
    public void insertImage(int image) {
        ImageView headDisplay = new ImageView();
        headDisplay.setImage(arrayHydraHeads[image]);
        headDisplay.setFitHeight(40);
        headDisplay.setFitWidth(40);
        pane.getChildren().add(headDisplay);
        displayedHeads.add(headDisplay);

        Random randomLocation = new Random();
        headDisplay.setTranslateX(randomLocation.nextInt(680));
        headDisplay.setTranslateY(randomLocation.nextInt(680));

        while(isSamePosition(headDisplay)){
            headDisplay.setTranslateX(randomLocation.nextInt(680));
            headDisplay.setTranslateY(randomLocation.nextInt(680));
        }

        headDisplay.setOnMouseClicked(mouseEvent -> {
            pane.getChildren().remove(headDisplay);
            counter++;
            finishGame();
            if(headDisplay.getImage().equals(arrayHydraHeads[1])){
                for(int i = 0; i < (int)(Math.random()*2)+2; i++) {
                    insertImage(0);
                }
            }
            else if(headDisplay.getImage().equals(arrayHydraHeads[2])){
                for(int i = 0; i < (int)(Math.random()*2)+2; i++) {
                    insertImage(1);
                }
            }
            else if(headDisplay.getImage().equals(arrayHydraHeads[3])){
                for(int i = 0; i < (int)(Math.random()*2)+2; i++) {
                    insertImage(2);
                }
            }
            else if(headDisplay.getImage().equals(arrayHydraHeads[4])){
                for(int i = 0; i < (int)(Math.random()*2)+2; i++) {
                    insertImage(3);
                }
            }
            else if(headDisplay.getImage().equals(arrayHydraHeads[5])) {
                for (int i = 0; i < (int) (Math.random() * 2) + 2; i++) {
                    insertImage(4);
                }
            }
        });
    }

    public boolean isSamePosition(ImageView currentLocation) {
        boolean status = false;
        for (ImageView images : displayedHeads){
            if (currentLocation != images){
                if (images.getBoundsInParent().intersects(currentLocation.getBoundsInParent())) {
                    status = true;
                    break;
                }
            }
        }
        return status;
    }
    @FXML
    public void onResetClick(){
        pane.getChildren().clear();
        playButton.setDisable(false);
        slider.setDisable(false);
        slider.setValue(4);
        counter = 0;
    }

    public void finishGame(){
        if(pane.getChildren().isEmpty()){
            Label finishText = new Label("Congrats! You've collected " + counter + " Hydra heads");
            pane.getChildren().add(finishText);
            finishText.setTranslateX(180);
            finishText.setTranslateY(325);
            finishText.setFont(new Font("Arial", 25));
            finishText.setAlignment((Pos.CENTER));
        }
    }


}